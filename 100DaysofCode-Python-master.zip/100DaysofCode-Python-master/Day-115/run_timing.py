#!/usr/bin/env python3

def run_timing():
    """
    Enter run time
    """
    counter = []
    while True:
        r_time = input("Enter 10 km run time: ")
        if r_time = "":
            return("Average of {}, {} runs".format(
                sum(counter), len(counter)
            ))
        else:

