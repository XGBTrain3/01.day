#!/usr/bin/env python3

import os

tmp_path = os.path.join("/tmp", "test")

print(tmp_path)

file_name = os.path.join(tmp_path, "file1.txt")

print(file_name)
