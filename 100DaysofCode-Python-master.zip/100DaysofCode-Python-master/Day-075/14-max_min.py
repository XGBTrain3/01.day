#!/usr/bin/env python3


def maximus(*args):
    """
    Find the largest number
    from a list of numbers
    """
    print(max(*args))
    return max(*args)


def minimus(*args):
    """Find the smallest number"""
    print(min(*args))
    return min(*args)
