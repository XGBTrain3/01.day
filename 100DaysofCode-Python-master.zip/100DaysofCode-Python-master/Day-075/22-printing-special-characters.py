#!/usr/bin/env python3

# 1. "\n" will be intrepreted as a new line.
print("I have a \n new line in the middle")

# 2. "\t" will be interpreted as a tab
print("I have a \t tab in the middle!")

# 3. Backslashes if part of the string, has to be
# escaped with another backslash to print properly.
print("I have a backslash \\ in the middle!")
