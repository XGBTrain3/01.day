#!/usr/bin/env python3


def squared(n):
    """This prints the square"""
    square = n ** 2
    print("%s squared is %s" % (n, square))
    return n, square
