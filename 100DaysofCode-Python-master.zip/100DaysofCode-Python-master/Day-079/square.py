#!/usr/bin/env python3

if __name__ == "__main__":
    n = int(input())

    num_list = range(n)
    for num in num_list:
        print(num * num)
