# Define create_spreadsheet():
def create_spreadsheet(title, row_count):
    print(
        "Creating a spreadsheet called " + title + " with " + str(row_count) + " rows"
    )


# Call create_spreadsheet() below with the required arguments:
create_spreadsheet("Applications", 10)
create_spreadsheet("Departments", 100)
