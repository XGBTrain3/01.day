def loading_screen():
    print("This page is loading...")


loading_screen()
