#!/usr/bin/env python3

# HackerRank 30-days of Code


class Person:
    def __init__(self, initialAge):
        pass


    def amIOld(self):
        pass


    def yearPasses(self):
        pass



t = int(input())
