#!/usr/bin/env python3

import calendar

cal = calendar.TextCalendar(calendar.SUNDAY)

print(cal.formatyear(2018))
