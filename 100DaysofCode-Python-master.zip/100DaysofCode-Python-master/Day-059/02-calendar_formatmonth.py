#!/usr/bin/env python3

import calendar

print(calendar.monthcalendar(2018, 2))
