#!/usr/bin/env python3

"""
Scrabble with dictionaries
"""
