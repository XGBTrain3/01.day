#!/usr/bin/env python3

first_name = "User"
last_name = "Name1"

print(f"{first_name} {last_name}")

