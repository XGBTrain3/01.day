#!/usr/bin/env python3

first_name = "ada"
last_name = "lovelace"

print(f"{first_name.title()} {last_name.title()}")
