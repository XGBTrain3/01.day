#!/usr/bin/env python3

from collections import ChainMap

print("Hello, how are you?")
