#!/usr/bin/env python3

# strings can be manipulated as lists.
# The first alphabet starts at position 0.

string_1 = "Testing python"

print(string_1[0:])
print(string_1[1:])
print(string_1[:-1])
print(string_1[0:-5])
