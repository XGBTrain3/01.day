#!/usr/bin/env python3

name = input("Enter your name: ")
print("Hello, {}".format(name))
