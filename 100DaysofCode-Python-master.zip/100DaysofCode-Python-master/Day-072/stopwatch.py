#!/usr/bin/env python3

# A program intented to work as a stopwatch

import time

input("Press `Enter` to begin.  Use `Ctrl + C` to quit")

start_time = time.time()
last_time = start_time

print("Stopwatch started.")
lap_count = 1
