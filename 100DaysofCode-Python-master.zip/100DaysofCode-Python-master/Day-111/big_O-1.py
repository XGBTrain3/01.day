#!/usr/bin/env python3

# Big O example 1

# O(1) or Constant time

items = ["bread", "milk", "scuba mix", "fruittella", "rice", "cucumber", "bonne mamman fig jam"]

def print_first_item(items):
    print(items[0])
    print(items[2])
    print(items[6])

print_first_item(items)


