#!/usr/bin/env python3

"""
Convert dates from US format `MM-DD-YYYY` to
UK format `DD-MM-YYYY`.
"""
