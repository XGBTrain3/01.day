#!/usr/bin/env python3

name = input("What is your name? ")
quest = input("What is your quest? ")
color = input("What is your favorite color? ")

print("Your name is {}, quest is {}, and color is {}".format(name, quest, color))
