#!/usr/bin/env python3

# Tuples

# Create tuples
tuple_1 = ()
print(type(tuple_1))

tuple_2 = tuple([10, 9, 8])
print("tuple_2 : {0}\n".format(tuple_2))

# Tuples are similar to lists, but are immutable.
tuple_4 = (1, 2, 3, 4, 5)
print("tuple_4 : {0}".format(tuple_4))
print("First element in tuple_4 : {0}".format(tuple_4[0]))
