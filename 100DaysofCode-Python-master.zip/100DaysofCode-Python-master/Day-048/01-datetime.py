#!/usr/bin/env python3

import datetime

today = datetime.date.today()

print("Day  : {}".format(today.day))
print("Month: {}".format(today.month))
print("Year : {}".format(today.year))
