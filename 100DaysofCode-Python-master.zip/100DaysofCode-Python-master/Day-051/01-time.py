#!/usr/bin/env python3

import time

# time.ctime() prints the current time, with the weekday, date etc.
print("The date / time now is {}".format(time.ctime()))
