#100DaysofCode

* Started doing Pybites/TalkPython #100DaysofCode challenge.