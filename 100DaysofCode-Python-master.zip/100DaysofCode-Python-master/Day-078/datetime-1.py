#!/usr/bin/env python3

import datetime

independence_day = datetime.date(2018, 8, 15)
print(independence_day)

today = datetime.datetime.now()
print(today)

print(independence_day - today)
